#!/bin/bash

dotnet ./gad.dll /downloadGithubArtifacts /gitRepoPath:/mnt/chumbucket4/src/repos/okta-oidc-xamarin /config:./Configs/gad.appsettings.lin.yaml