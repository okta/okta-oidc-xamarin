#!/bin/bash

dotnet ./gad.dll /createGadPackage